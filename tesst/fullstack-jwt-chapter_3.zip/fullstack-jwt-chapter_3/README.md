# Fullstack project with JWT authentication & authorization

Explanatory video: https://youtu.be/g4mx3Q1loL0

The current project shows how to authenticate with JWT from a React frontend to a Spring Boot backend.

You can find more details in the README files of the respective folders.
