package com.sergio.jwt.backend.dtos;

public record MessageDto (String message) {
}
